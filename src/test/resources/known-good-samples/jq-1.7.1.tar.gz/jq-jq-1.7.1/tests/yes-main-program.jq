def a: .;
0
